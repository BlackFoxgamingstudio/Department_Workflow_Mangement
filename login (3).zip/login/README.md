Code that goes along with a video I made here: https://www.youtube.com/watch?v=vVx1737auSE

This is for a user login system using Flask and MongoDB.
