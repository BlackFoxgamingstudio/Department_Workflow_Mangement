from flask import *
import jsonpickle
from flask import Flask, render_template, url_for, request, session, redirect
from flask_pymongo import PyMongo
import bcrypt
from hashlib import md5
from flask_login import current_user, login_user
from flask_security import login_required
debug=True
app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://naruto45me:N%40ruto45me@ds062448.mlab.com:62448/keytechlabs'

mongo = PyMongo(app)
########################
# Flask Server Example #
########################
 
##LEADERBOARD
## This will be a list with simple dict inside (eg. [{name: Joe, score: 10},{name: Jane, score: 20}])

leaderboard = []
id = 0
@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('home'))

    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    users = mongo.db.users.find({})
    login_user = users.find_one({'name' : request.form['username']})
        
    if login_user:


        if bcrypt.hashpw(request.form['pass'].encode('utf-8'), login_user['password'].encode('utf-8')) == login_user['password'].encode('utf-8'):
            session['username'] = request.form['username']
            
            return redirect(url_for('index'))

    return 'Invalid username/password combination'

@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        users = mongo.db.users
        existing_user = users.find_one({'name' : request.form['username']})

        if existing_user is None:
            hashpass = bcrypt.hashpw(request.form['pass'].encode('utf-8'), bcrypt.gensalt())
            users.insert({'name' : request.form['username'], 'password' : hashpass})
            session['username'] = request.form['username']
            return redirect(url_for('index'))
        
        return 'That username already exists!'

    return render_template('register.html') 
# INDEX PAGE
@app.route('/leaderboard')
def home():
    lb_id= 0
    Users=mongo.db.users.find({})
    login_user = mongo.db.users.find_one({'name' : session['username']})
    return render_template('leaderboard.html', Users=Users, login_user=login_user)
  
# GET LEADERBOARD
@app.route('/api/getleaders')
def get_leader():
    global leaderboard
    print "Getting Leaderboard"
    print leaderboard
    return jsonpickle.encode(leaderboard)
 
# ADD ENTRY
@app.route('/api/addentry/',methods=['GET', 'POST'])
def add_entry():
    global leaderboard,id
    print "Adding Entry"
    if request.method == 'POST':
        name = request.form['name']
        score = request.form['score']
        
    leaderboard += [{"id":id,"name":request.form['name'],"score":request.form['score']}]
    return redirect(url_for('home'))
 
# REMOVE ENTRY
@app.route('/api/rmentry/', methods=['DELETE'])
def rm_entry(entry_id):
    global leaderboard
    print "Removing Entry!"
 
    for entry in leaderboard:
        if entry["id"] == entry_id:
            leaderboard.remove(entry)
            break;
 
    return jsonpickle.encode(leaderboard)
 
@app.route('/user/<username>')
@login_required
def user(username):
    user = User.query.filter_by(username=username).first_or_404()
    posts = [
        {'author': user, 'body': 'Test post #1'},
        {'author': user, 'body': 'Test post #2'}
    ]
    return render_template('user.html', user=user, posts=posts)
    
if __name__ == "__main__":
 
    app.debug = True
    app.secret_key = 'mysecret'
    app.run(port=80)    
   